package com.example.EmpMngmt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmpMngmtApplicationTests {

	@Test
	void contextLoads() {
	}

}
